# netflix-homepage
created homepage of netflix using html css and js
